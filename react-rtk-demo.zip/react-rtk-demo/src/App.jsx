import { useState } from "react";
import "./App.css";
import CakeView from "./features/cake/CakeView.jsx";
import UserView from "./features/user/UserView.jsx";
import IceCreamView from "./features/icecreame/IceCreamView.jsx";

function App() {
  const [count, setCount] = useState(0);

  return (
    <div className="App">
      <CakeView />
      <IceCreamView />
      <UserView /> 
    </div>
  );
}

export default App;
