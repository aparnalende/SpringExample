module.exports = {
  secret: "bezkoder-secret-key"
};
