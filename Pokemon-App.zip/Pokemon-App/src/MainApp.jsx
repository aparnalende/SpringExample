import React, { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import Router from "./common/Routes";

function App() {
  return (
    <div className="app-container">
      <Router />
      <Outlet />
    </div>
  );
}

export default App;
