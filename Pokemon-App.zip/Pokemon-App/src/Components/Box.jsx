import React from "react";

function Box() {
  return <div></div>;
}

export default Box;
