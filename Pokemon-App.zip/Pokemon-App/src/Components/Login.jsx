import React, { useState } from "react";
import InputAdornment from "@mui/material/InputAdornment";

import IconButton from "@mui/material/IconButton";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { useTheme } from "@mui/material/styles";
import "../css/register.css";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { Button, Divider } from "@mui/material";
import { useForm } from "react-hook-form";
import { LoginSchema } from "../common/ValidationSchema";
import { yupResolver } from "@hookform/resolvers/yup";
import { Link, useNavigate } from "react-router-dom";
import axios from "axios";
import API from "../common/urls";
import TextField from "../common/Input";

function Login() {
  const navigate = useNavigate();
  const [loginData, setloginData] = useState({
    username: "",
    password: "",
  });
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(LoginSchema),
  });
  const onSubmit = (data) => {
    console.log("login data", data);
    axios
      .post(API.LOGIN_USER, {
        ...data,
      })
      .then((response) => {
        console.log(response, "***********");
        localStorage.setItem("user", JSON.stringify(response.data));
        navigate("/");
      })
      .catch((error) => console.log(error));
  };

  const handleOnchange = (e) => {
    console.log(">>>>>>Onchange hitted");
    setloginData({ ...loginData, username: e.target.value });
  };
  return (
    <div className="register__wrapper">
      <div className="register__Form">
        <div className="register__img">
          <img
            src="user_logo.png"
            alt=""
            className="register__img"
            width="120px"
          />
        </div>
        <h2>Sign In </h2>
        <Divider></Divider>
        <div className="register__divider">
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="username">
              <InputLabel>Username</InputLabel>
              <div className="form__group">
                {" "}
                <TextField
                  size="small"
                  placeholder="Enter username"
                  type="username"
                  name="username"
                  handleOnchange={handleOnchange}
                  register={{ ...register("username") }}
                />
                {errors?.username && (
                  <p className="error__field">{errors?.username?.message}</p>
                )}
              </div>
            </div>
            <div className="password">
              <InputLabel>Password</InputLabel>
              <div className="form__group">
                {" "}
                <TextField
                  size="small"
                  placeholder="Enter password"
                  type="password"
                  name="password"
                  handleOnchange={handleOnchange}
                  register={{ ...register("password") }}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        edge="end"
                      >
                        {/* {showPassword ? <VisibilityOff /> : <Visibility />} */}
                        <VisibilityOff />
                      </IconButton>
                    </InputAdornment>
                  }
                />
                {errors?.password && (
                  <p className="error__field">{errors?.password?.message}</p>
                )}
              </div>
            </div>

            <div className="submit__btn">
              <Button type="submit">Submit</Button>
            </div>
            <Link to={"/register"}>Don't have an account</Link>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
