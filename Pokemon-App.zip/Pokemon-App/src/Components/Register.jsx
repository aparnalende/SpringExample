// import React, { useState } from "react";
// import InputAdornment from "@mui/material/InputAdornment";
// import TextField from "@mui/material/TextField";
// import IconButton from "@mui/material/IconButton";
// import VisibilityOff from "@mui/icons-material/VisibilityOff";
// import { useTheme } from "@mui/material/styles";
// import "../css/register.css";
// import OutlinedInput from "@mui/material/OutlinedInput";
// import InputLabel from "@mui/material/InputLabel";
// import MenuItem from "@mui/material/MenuItem";
// import FormControl from "@mui/material/FormControl";
// import Select from "@mui/material/Select";
// import { Button, Divider } from "@mui/material";
// import { RegisterSchema } from "../common/ValidationSchema";
// import { useForm } from "react-hook-form";
// import { yupResolver } from "@hookform/resolvers/yup";
// import API from "../common/urls";
// import axios from "axios";
// import { Link, useNavigate } from "react-router-dom";
// const ITEM_HEIGHT = 48;
// const ITEM_PADDING_TOP = 8;
// const MenuProps = {
//   PaperProps: {
//     style: {
//       maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
//       width: 250,
//     },
//   },
// };

// const names = [
//   {
//     id: "user",
//     value: "user",
//   },
//   {
//     id: "Moderator",
//     value: "Moderator",
//   },
// ];

// function getStyles(name, personName, theme) {
//   return {
//     fontWeight:
//       personName.indexOf(name) === -1
//         ? theme.typography.fontWeightRegular
//         : theme.typography.fontWeightMedium,
//   };
// }
// function Register() {
//   const theme = useTheme();
//   const [personName, setPersonName] = React.useState([]);
//   const [selectroles, setSelectroles] = useState("");
//   const navigate = useNavigate();
//   const [registerData, setRegisterData] = useState({
//     firstName: "",
//     lastName: "",
//     email: "",
//     password: "",
//     roles: "",
//   });
//   const {
//     register,
//     handleSubmit,
//     watch,
//     formState: { errors },
//   } = useForm({
//     resolver: yupResolver(RegisterSchema),
//   });
//   const handleChange = (event) => {
//     const {
//       target: { value },
//     } = event;
//     console.log("value", value);
//     setPersonName(
//       // On autofill we get a stringified value.
//       typeof value === "string" ? value.split(",") : value
//     );

//     setRegisterData({ ...registerData, roles: value });
//   };

//   const onSubmit = (data) => {
//     console.log("data", API);
//     const response = axios
//       .post("http://localhost:4000/user", {
//         data,
//       })
//       .then((response) => {
//         console.log(response.data.data, "***********");
//         navigate("/login");
//       })
//       .catch((error) => console.log(error));

//     console.log("response=====", response);
//   };

//   return (
//     <div className="register__wrapper">
//       <div className="register__Form">
//         <h2>Sign Up </h2>
//         <div className="register__img">
//           <img
//             src="user_logo.png"
//             alt=""
//             className="register__img"
//             width="150px"
//           />
//         </div>

//         <Divider></Divider>
//         <div className="register__divider">
//           <form onSubmit={handleSubmit(onSubmit)}>
//             <div className="fullname">
//               <div className="form__field">
//                 <div className="labels">
//                   {" "}
//                   <InputLabel>Firstname</InputLabel>{" "}
//                 </div>
//                 <TextField
//                   placeholder="Enter fname"
//                   className="fname_textfield"
//                   name="firstName"
//                   onChange={(e) =>
//                     setRegisterData({
//                       ...registerData,
//                       firstName: e.target.value,
//                     })
//                   }
//                   {...register("firstName")}
//                 />
//                 {errors?.firstName && (
//                   <p className="error__field">{errors?.firstName?.message}</p>
//                 )}
//               </div>
//               <div className="form__field">
//                 <div className="labels">
//                   {" "}
//                   <InputLabel>Lastname</InputLabel>
//                 </div>
//                 <TextField
//                   placeholder="Enter lname"
//                   className="lname_textfield"
//                   name="lastName"
//                   onChange={(e) =>
//                     setRegisterData({
//                       ...registerData,
//                       lastName: e.target.value,
//                     })
//                   }
//                   {...register("lastName")}
//                 />
//                 {errors?.lastName && (
//                   <p className="error__field">{errors?.lastName?.message}</p>
//                 )}
//               </div>
//             </div>
//             <div className="email">
//               <InputLabel>Email</InputLabel>
//               <div className="form__group">
//                 {" "}
//                 <TextField
//                   placeholder="Enter email"
//                   type="email"
//                   name="email"
//                   onChange={(e) =>
//                     setRegisterData({
//                       ...registerData,
//                       email: e.target.value,
//                     })
//                   }
//                   {...register("email")}
//                 />
//                 {errors?.email && (
//                   <p className="error__field">{errors?.email?.message}</p>
//                 )}
//               </div>
//             </div>
//             <div className="password">
//               <InputLabel>Password</InputLabel>
//               <div className="form__group">
//                 <TextField
//                   placeholder="Enter password"
//                   type="password"
//                   name="password"
//                   onChange={(e) =>
//                     setRegisterData({
//                       ...registerData,
//                       password: e.target.value,
//                     })
//                   }
//                   {...register("password")}
//                   endAdornment={
//                     <InputAdornment position="end">
//                       <IconButton
//                         aria-label="toggle password visibility"
//                         // onClick={handleClickShowPassword}
//                         // onMouseDown={handleMouseDownPassword}
//                         edge="end"
//                       >
//                         {/* {showPassword ? <VisibilityOff /> : <Visibility />} */}
//                         <VisibilityOff />
//                       </IconButton>
//                     </InputAdornment>
//                   }
//                 />
//                 {errors?.password && (
//                   <p className="error__field">{errors?.password?.message}</p>
//                 )}
//               </div>
//             </div>
//             <div className="select_roless">
//               <InputLabel id="demo-multiple-name-label">
//                 Select roles
//               </InputLabel>
//               <div className="form__group">
//                 <FormControl width={300}>
//                   <Select
//                     labelId="demo-multiple-name-label"
//                     id="demo-multiple-name"
//                     // multiple
//                     name="roles"
//                     onChange={(e) => {
//                       handleChange(e);
//                     }}
//                     renderValue={(value) =>
//                       // value?.length
//                       //   ? Array.isArray(value)
//                       //     ? value.join(", ")
//                       //     : value
//                       //   : "Choose roles"
//                       value ? value : "Choose roles"
//                     }
//                     input={<OutlinedInput label="Name" />}
//                     MenuProps={MenuProps}
//                     {...register("roles")}
//                   >
//                     {names.map((option) => (
//                       <MenuItem key={option.value} value={option.value}>
//                         {option.value}
//                       </MenuItem>
//                     ))}
//                   </Select>
//                 </FormControl>
//                 {errors?.roles && (
//                   <p className="error__field">{errors?.roles?.message}</p>
//                 )}
//               </div>
//             </div>
//             <div className="btn__div">
//               <div className="submit__btn">
//                 <Button type="submit">Submit</Button>
//               </div>
//             </div>
//             <Link to={"/login"}>Already register</Link>
//           </form>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default Register;
import React, { useState } from "react";
import InputAdornment from "@mui/material/InputAdornment";
// import TextField from "@mui/material/TextField";
import TextField from "../common/Input";
import IconButton from "@mui/material/IconButton";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import { useTheme } from "@mui/material/styles";
import "../css/register.css";
import OutlinedInput from "@mui/material/OutlinedInput";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { Button, Divider } from "@mui/material";
import { RegisterSchema } from "../common/ValidationSchema";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import API from "../common/urls";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";
const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

const names = [
  {
    id: "user",
    value: "user",
  },
  {
    id: "moderator",
    value: "moderator",
  },
];

function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}
function Register() {
  const theme = useTheme();
  const [personName, setPersonName] = React.useState([]);
  const [selectroles, setSelectroles] = useState("");
  const navigate = useNavigate();
  const [registerData, setRegisterData] = useState({
    username: "",
    email: "",
    password: "",
    roles: [],
  });
  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm({
    resolver: yupResolver(RegisterSchema),
  });
  const handleChange = (event) => {
    const {
      target: { value },
    } = event;
    console.log("value", value);
    setPersonName(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );

    setRegisterData({ ...registerData, roles: [value] });
  };

  const onSubmit = (data) => {
    console.log("data", data);
    let roles = [data.roles];
    let d = {
      ...data,
      roles: roles,
    };
    console.log("data DDD>>>>", d);

    const response = axios
      .post(API.ADD_USER, {
        ...d,
      })
      .then((response) => {
        console.log(response, "***********");
        navigate("/login");
      })
      .catch((error) => console.log(error));

    console.log("response=====", response);
  };

  const handleOnChange = (name, e) => {
    console.log("VALUE", e);
    setRegisterData({
      ...registerData,
      name: e.target.value,
    });
  };
  console.log("register data", registerData);
  return (
    <div className="register__wrapper">
      <div className="register__Form">
        <div className="register__img">
          <img
            src="user_logo.png"
            alt=""
            className="register__img"
            width="120px"
          />
        </div>
        <h2>Sign Up </h2>
        <Divider></Divider>
        <div className="register__divider">
          <form onSubmit={handleSubmit(onSubmit)}>
            <div className="form-control">
              <InputLabel>username</InputLabel>{" "}
              <div className="form__group">
                {" "}
                <TextField
                  size="small"
                  placeholder="Enter fname"
                  // className="fname_textfield"
                  name="username"
                  onChange={(e) => handleOnChange("username", e)}
                  register={{ ...register("username") }}
                />
              </div>
              {errors?.username && (
                <p className="error__field">{errors?.username?.message}</p>
              )}
            </div>

            <div className="form-control">
              <InputLabel>Email</InputLabel>
              <div className="form__group">
                {" "}
                <TextField
                  size="small"
                  placeholder="Enter email"
                  type="email"
                  name="email"
                  onChange={(e) => handleOnChange("email", e)}
                  register={{ ...register("email") }}
                />
                {errors?.email && (
                  <p className="error__field">{errors?.email?.message}</p>
                )}
              </div>
            </div>
            <div className="form-control">
              <InputLabel>Password</InputLabel>
              <div className="form__group">
                <TextField
                  size="small"
                  placeholder="Enter password"
                  type="password"
                  name="password"
                  onChange={(e) => handleOnChange("password", e)}
                  register={{ ...register("password") }}
                  endAdornment={
                    <InputAdornment position="end">
                      <IconButton
                        aria-label="toggle password visibility"
                        // onClick={handleClickShowPassword}
                        // onMouseDown={handleMouseDownPassword}
                        edge="end"
                      >
                        {/* {showPassword ? <VisibilityOff /> : <Visibility />} */}
                        <VisibilityOff />
                      </IconButton>
                    </InputAdornment>
                  }
                />
                {errors?.password && (
                  <p className="error__field">{errors?.password?.message}</p>
                )}
              </div>
            </div>
            <div className="select_roless form-control">
              <InputLabel id="demo-multiple-name-label">
                Select roles
              </InputLabel>
              <div className="form__group">
                <FormControl width={300}>
                  <Select
                    size="small"
                    labelId="demo-multiple-name-label"
                    id="demo-multiple-name"
                    // multiple
                    name="roles"
                    onChange={(e) => {
                      handleChange(e);
                    }}
                    renderValue={(value) =>
                      // value?.length
                      //   ? Array.isArray(value)
                      //     ? value.join(", ")
                      //     : value
                      //   : "Choose roles"
                      value.length > 0 ? value : "Choose roles"
                    }
                    input={<OutlinedInput label="Name" />}
                    MenuProps={MenuProps}
                    {...register("roles")}
                  >
                    {names.map((option) => (
                      <MenuItem key={option.value} value={option.value}>
                        {option.value}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
                {errors?.roles && (
                  <p className="error__field">{errors?.roles?.message}</p>
                )}
              </div>
            </div>
            <div className="btn__div">
              <div className="submit__btn">
                <Button type="submit">Submit</Button>
              </div>
            </div>
            <Link to={"/login"}>Already register</Link>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Register;
