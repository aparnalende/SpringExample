import React from "react";

function Moderator() {
  const userData = JSON.parse(localStorage.getItem("user"));
  const { username } = userData;
  return (
    <>
      <div>
        <h2>Username: {username}</h2>
      </div>
    </>
  );
}

export default Moderator;
