import { makeStyles } from "@mui/material";
import { React } from "react";

const Placeholder = ({ children }) => {
  return <div className="placeholder">{children}</div>;
};
export default Placeholder;
