import * as yup from "yup";

const RegisterSchema = yup
  .object({
    // firstName: yup.string().required("Firstname is required"),
    // lastName: yup.string().required("Lastname is required"),
    username: yup.string().required("Username is required"),

    email: yup
      .string()
      .required("Enter email address")
      .email("Not a proper email"),
    password: yup
      .string()
      .required("Please Enter your password")
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
        "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
      ),
    roles: yup.string().required(),
    // roles: yup.string().required("Role is required"),

    // age: yup.number().positive().integer().required(),
  })
  .required();

const LoginSchema = yup
  .object({
    username: yup.string().required("Enter username"),

    password: yup
      .string()
      .required("Please enter your password")
      .matches(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
        "Must Contain 8 Characters, One Uppercase, One Lowercase, One Number and One Special Case Character"
      ),
  })
  .required();

export { RegisterSchema, LoginSchema };
