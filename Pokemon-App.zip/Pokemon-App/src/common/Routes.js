import React from "react";
import { Route, Routes } from "react-router-dom";
import Login from "../Components/Login";
import Register from "../Components/Register";
import Navbar from "../Components/Navbar";
import Home from "../Components/Home";
import User from "../Components/User";
import Moderator from "../Components/Moderator";
function Router() {
  return (
    <div>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/register" element={<Register />} />
        <Route path="/user" element={<User />} />
        <Route path="/moderator" element={<Moderator />} />
      </Routes>
    </div>
  );
}

export default Router;
