const BASE_URL = "http://localhost:5000/api/";
const API = {
  ADD_USER: BASE_URL + "auth/signup",
  LOGIN_USER: BASE_URL + "auth/signin",
};
export default API;
