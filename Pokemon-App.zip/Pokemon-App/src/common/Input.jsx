import { TextField } from "@mui/material";
import React from "react";
import "../css/register.css";
function Input(props) {
  console.log(props);
  return (
    <>
      <TextField
        size={props.size}
        placeholder={props.placeholder}
        type={props.type}
        name={props.name}
        onChange={props.handleOnchange}
        {...props.register}
      />
    </>
  );
}

export default Input;
