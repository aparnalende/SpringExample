import { createSlice } from "@reduxjs/toolkit";

export const userSlice = createSlice({
  name: "user",
  initialState: {
    user: {},
  },
  reducer: {
    login: (state) => {
      return state.user;
    },
  },
});
